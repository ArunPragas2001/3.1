hello:-write('Hello world').
welcome:-write('welcome to Knowledge based systems').
mul:-write('Knowledge Based Systems'),nl,
    write('Logic Programming'),nl,
    write('Prolog Practical').
start:-hello,nl,welcome.
details:-
    write('Name:'),write('Arun'),nl,
    write('Course:'),write('IT'),nl,
    write('Preferences:'),write('Programming').
greet(Name):-
write('Name:'),write(Name).

student(Name):-
    write('Student Name: '),write(Name).
student_Report(Name):-
    write('****************************************'),nl,
    tab(7), write('STUDENT REPORT'),nl,
    write('****************************************'),nl,
    write("Name :" ),write(Name),nl,
    write('Course : '),write('Knowledge Based Systems'),nl,
    write('Practical : '),write('Prolog'),nl,
    write('****************************************').
likes(john,pizza).


















