students([amal, kamal, nimal, saman, ravi]).

first_student([First|_], First).

rest_students([_|Rest], Rest).

registered(Student) :-
    students(List),
    member(Student, List).

number_of_students() :-
    students(List),
    length(List).

add_fathima(NewList) :-
    students(List),
    append(List, [fathima], NewList).

likes(amal,mango).
likes(amal,apple).
likes(amal,banana).
likes(amal,guava).






fruits([mango,pumpkin,guava,apple]).

f_fruit([F|_],F).
rest_f([_|R],R).
bought_fruit(Fruit):-
    fruits(List),
    member(List,Number).

num_of_f(Num):-
    fruits(List),
    length(List,Num).
add_f(NewList):-
    fruits(List),
    append(List,[jambu],NewList).

likes(amal,mango).
likes(amal,apple).
likes(kamal,banana).
likes(kamal,guava).

choose(X):-X=apple,!.
choose(guava).
choose(apple).


