numbers([10,20,30,40,50]).

empty_list([]).

traverse([]).
traverse_list([H|T]):-
    write(H),
    nl,
    traverse_list(T).

list_length([],0).
list_length([_|T],Length):-
    list_length(T,L),
    Length is L+1.

